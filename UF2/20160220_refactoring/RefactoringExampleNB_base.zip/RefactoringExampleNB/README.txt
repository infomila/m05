This example code is from Martin Fowler's book Refactoring: Improving the Design of Existing Code.

