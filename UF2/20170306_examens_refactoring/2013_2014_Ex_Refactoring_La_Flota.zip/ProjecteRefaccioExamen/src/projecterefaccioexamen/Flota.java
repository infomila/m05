package projecterefaccioexamen;

import java.text.NumberFormat;
import java.util.ArrayList;

public class Flota {
    
    private ArrayList<Vehicle> vehicles;

    public Flota( ) {
        this.vehicles = new ArrayList<Vehicle>();
    }
    
    
    public void addVehicle(Vehicle nou){
        if(nou==null) {
            throw new RuntimeException("El vehicle no pot ser null");
        }
        for(Vehicle v: vehicles){
            if(v.getMatricula().equals(nou.getMatricula())) throw new RuntimeException("Element repetit");
        }
        vehicles.add(nou);
    }
    
    public String getInformeFlota(){
        int totalCotxes=0, totalMotos=0, totalCamions=0;
        float totalConsumsEur100KmCotxes=0, totalConsumsEur100KmMotos=0, totalConsumsEur100KmCamions=0;
        String resultat =   "========================================\n";
        resultat +=         "===   Informe de la flota de vehicles  =\n";
        resultat +=         "========================================\n";
        int consumL100Km;
        double consumEur100Km=0;
        NumberFormat nf = NumberFormat.getNumberInstance();
        nf.setMaximumFractionDigits(2);
        nf.setMinimumFractionDigits(2);
        for(Vehicle current: vehicles){
            if(current.getTipus()==Vehicle.CAMIO) {
                resultat += "Camió amb matricula "+current.getMatricula()+"\n";
                consumL100Km = (int) (Math.log(current.getPes())*3.7);
                resultat += "Consum: "+consumL100Km+" l/100Km\n";
                switch(current.getTipusBenzina()) {
                    case Vehicle.GASOIL:        consumEur100Km = consumL100Km *1.34;break;
                    case Vehicle.GASOLINA_95:   consumEur100Km = consumL100Km *1.47;break;
                }
                resultat += "        "+nf.format(consumEur100Km)+" €/100Km\n";
                totalCamions++;
                totalConsumsEur100KmCamions += consumEur100Km;
            } else if(current.getTipus()==Vehicle.COTXE) {
                resultat += "Cotxe amb matricula "+current.getMatricula()+"\n";
                consumL100Km = 6;
                if(current.getPes()<1000) {
                    consumL100Km = 4;
                }else if(current.getPes()>2500) {
                    consumL100Km = 10;
                } else if(current.getPes()>3500) {
                    consumL100Km = 14;
                }
                resultat += "Consum: "+consumL100Km+" l/100Km\n";
                switch(current.getTipusBenzina()) {
                    case Vehicle.GASOIL:        consumEur100Km = consumL100Km *1.34;break;
                    case Vehicle.GASOLINA_95:   consumEur100Km = consumL100Km *1.47;break;
                }
                resultat += "        "+nf.format(consumEur100Km)+" €/100Km\n";
                totalCotxes++;
                totalConsumsEur100KmCotxes += consumEur100Km;
                 
            } else if(current.getTipus()==Vehicle.MOTO) {
                consumL100Km = current.getPes() / 50;
                if(consumL100Km==0) {
                    consumL100Km = 1;
                }
                resultat += "Moto amb matricula "+current.getMatricula()+"\n";
                resultat += "Consum: "+consumL100Km+" l/100Km\n";
                switch(current.getTipusBenzina()) {
                    case Vehicle.GASOIL:        consumEur100Km = consumL100Km *1.34;break;
                    case Vehicle.GASOLINA_95:   consumEur100Km = consumL100Km *1.47;break;
                }
                resultat += "        "+nf.format(consumEur100Km)+" €/100Km\n";
                totalMotos++;
                totalConsumsEur100KmMotos += consumEur100Km;
            } else {
                throw new RuntimeException("Tipus deconegut");
            }
            resultat +=         "----------------------------------------\n";

        }
        resultat +=     "========================================\n";
        resultat +=     "===    Resum de consums per tipus    ===\n";
        resultat +=     "========================================\n";
        resultat +=   "Camions:"+nf.format(totalConsumsEur100KmCamions)+" €/100Km\n";
        resultat +=   "Cotxes:"+nf.format(totalConsumsEur100KmCotxes)+" €/100Km\n";
        resultat +=   "Motos:"+nf.format(totalConsumsEur100KmMotos)+" €/100Km\n";     
        return resultat;
    }
    public static void main(String [] args){
     
        Flota f = new Flota();
        f.addVehicle(new Vehicle(10000, Vehicle.CAMIO, "3423-VFC", Vehicle.GASOIL, 800));
        f.addVehicle(new Vehicle(20000, Vehicle.CAMIO, "3643-FCV", Vehicle.GASOIL, 900));
        f.addVehicle(new Vehicle(2000, Vehicle.COTXE, "3333-DDR", Vehicle.GASOLINA_95, 60));
        f.addVehicle(new Vehicle(2500, Vehicle.COTXE, "5555-DDR", Vehicle.GASOIL, 80));
        f.addVehicle(new Vehicle(120, Vehicle.MOTO, "3423-XXX", Vehicle.GASOLINA_95, 20));
        System.out.println(f.getInformeFlota());
    }
    
}
