package aillament;

/**
 *
 * @author bernat
 */
public class ProducteBD {

    public  int getStockProducte(int codiProducte) {
        throw new UnsupportedOperationException("BD no disponible als tests !!");
    }

    public Producte getProducte(int codiProducte) {
        throw new UnsupportedOperationException("BD no disponible als tests !!"); 
    }

}
