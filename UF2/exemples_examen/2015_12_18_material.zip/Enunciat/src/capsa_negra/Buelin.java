package capsa_negra;

/**
 *
 * @author bernat
 */
public class Buelin {


    public float getSobrecostPerEquipatge(  
                                            int midaEquipatgeMaCm[],  
                                            int pesEquipatgeMa, 
                                            int pesMaletes[], 
                                            boolean pagaAmbTarja){
        return -1;
    }
}
