package net.iesmila.ed.uf2_2.aillament;

import java.util.ArrayList;

/**
 *
 * @author BERNAT
 */
public class InfoCine {
    
    public String getInfo(String localitat)  {
        CinemaWebService cws = new CinemaWebService();
        ArrayList<String> sales = cws.getSales(localitat);
        String info="";
        if(sales!=null && sales.size()>0) {
            info += "==========================\n";
            info += "Cinemes a " + localitat + "\n";            
            info += "==========================\n";
            for(String s:sales) {
                int butaques = cws.getNumButaques(s);
                info += "\t-" + s+" - " + butaques +" butaques\n";            
            }
        } else {
            info += "==========================\n";
            info += "La localitat " + localitat  + " no té cinemes.\n";            
            info += "==========================\n";
        }
        return info;
    }
    
}
