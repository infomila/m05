package net.iesmila.ed.uf2_2.capsa_negra;

 import java.util.Arrays;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 *
 * @author BERNAT
 */
public class Poker {

    public static WinEnum whoWins(CardEnum handA[], CardEnum handB[]) {
        if(handA==null) return WinEnum.INVALID_HAND;
        if(handB==null) return WinEnum.INVALID_HAND;
        if(handA.length!=5) return WinEnum.INVALID_HAND;
        if(handB.length!=5) return WinEnum.INVALID_HAND;
        
        
        
        int colorA[] = {0, 0, 0, 0};
        int colorB[] = {0, 0, 0, 0};

        int frequenciesA[] = new int[13];
        int frequenciesB[] = new int[13];
        int frequenciesT[] = new int[CardEnum.values().length];
        
        for (int i = 0; i < frequenciesA.length; i++) {
            frequenciesT[i] = frequenciesT[i] = 0;
         }

        for (int i = 0; i < handA.length; i++) {
            frequenciesA[handA[i].ordinal()%13]++;
            frequenciesB[handB[i].ordinal()%13]++;
            frequenciesT[handA[i].ordinal()]++;
            frequenciesT[handB[i].ordinal()]++;
            colorA[handA[i].ordinal() / 13]++;
            colorB[handB[i].ordinal() / 13]++;
        }
        // sense cartes repetides !
        for (int i = 0; i < frequenciesT.length; i++) {
            //if(frequenciesT[i]>1) return WinEnum.INVALID_HAND;
         }

        int repsA[] = new int[]{0, 0, 0, 0, 0};
        int repsB[] = new int[]{0, 0, 0, 0, 0};
        for (int i = 0; i < frequenciesA.length; i++) {
            repsA[frequenciesA[i]]++;
            repsB[frequenciesB[i]]++;
        }

        Mans maA = getMa(repsA, colorA, handA);
        Mans maB = getMa(repsB, colorB, handB);

        System.out.println("MA A " + maA);
        System.out.println("MA B " + maB);
        if (maA.ordinal() > maB.ordinal()) {
            return WinEnum.A;
        }
        if (maB.ordinal() > maA.ordinal()) {
            return WinEnum.B;
        }

        //Desempat
        List<CardEnum> listA = ordena(handA);
        List<CardEnum> listB = ordena(handB);
        if (maA == Mans.ESCALA || maA == Mans.ESCALA_COLOR) {
            if (listA.get(0).ordinal()%13 > listB.get(0).ordinal()%13) {
                return WinEnum.A;
            }
            if (listB.get(0).ordinal() > listA.get(0).ordinal()%13) {
                return WinEnum.B;
            }
            return WinEnum.TIE;
        } else if (maA == Mans.FULL) {
            int trioA = 0, trioB = 0;
            int parellaA = 0, parellaB = 0;
            for (int i = 0; i < frequenciesA.length; i++) {
                if (frequenciesA[i] == 3) {
                    trioA = getNumber(i);
                }
                if (frequenciesB[i] == 3) {
                    trioB = getNumber(i);
                }
                if (frequenciesA[i] == 2) {
                    parellaA = getNumber(i);
                }
                if (frequenciesB[i] == 2) {
                    parellaB = getNumber(i);
                }
            }
            if (trioA > trioB || (trioA == trioB && parellaA > parellaB)) {
                return WinEnum.A;
            }
            if (trioA < trioB || (trioA == trioB && parellaA < parellaB)) {
                return WinEnum.B;
            }
            return WinEnum.TIE;
        } else {
            
            System.out.println("EMPAT¿?");
            int valorA=0, valorB=0;
            for (int i = 0; i < frequenciesA.length; i++) {
                if (frequenciesA[i] >1) {
                    valorA = getNumber(i);
                }
                if (frequenciesB[i] >1) {
                    valorB = getNumber(i);
                }
            }
            System.out.println("EMPAT¿?"+valorA+"-"+valorB);
            if (valorA > valorB  ) {
                return WinEnum.A;
            }
            if (valorB > valorA  ) {
                return WinEnum.B;
            }
                        
            for(int i=0;i<listA.size();i++) {
                //System.out.println("EMPAT¿?"+listA.get(i).ordinal()+"-"+listB.get(i).ordinal());

                if(listA.get(i).ordinal()%13>listB.get(i).ordinal()%13) return WinEnum.A;
                if(listA.get(i).ordinal()%13<listB.get(i).ordinal()%13) return WinEnum.B;
            }
            
            return WinEnum.TIE;
        }

    }

    public static Mans getMa(int[] reps, int[] color, CardEnum[] hand) {
        Mans m = Mans.SENSE_JUGADA;
        if (reps[1] == 5) {
            m = Mans.SENSE_JUGADA;
        } else if (reps[4] == 1) {
            m = Mans.POKER;
        } else if (reps[3] == 1) {
            if (reps[2] == 1) {
                m = Mans.FULL;
            } else {
                m = Mans.TRIO;
            }
        } else if (reps[2] >= 1) {
            m = Mans.PARELLA;
        }

        // verificar cas color
        if (color[0] == 5 || color[1] == 5 || color[2] == 5 || color[3] == 5) {
                m = Mans.COLOR;
         }

        if (m == Mans.SENSE_JUGADA || m == Mans.COLOR) {
            System.out.println("Hand : "+hand);
            List<CardEnum> list = ordena(hand);
            System.out.println("Hand ordenada : "+list);
            int prev = -1;
            boolean esEscala = true;
            for (int i = 0; i < list.size(); i++) {
                int curr = getNumber(list.get(i));
                if (prev != -1) {
                    if (curr != prev - 1) {
                        esEscala = false;
                        break;
                    }
                }
                prev = curr;
            }
            if (esEscala) {
                if (m == Mans.COLOR) {
                    m = Mans.ESCALA_COLOR;
                } else {
                    m = Mans.ESCALA;
                }
            }
        }
        return m;
        // cal testejar totes les permutacions de mans
    }

    public static List<CardEnum> ordena(CardEnum[] hand) {
        //verificar escala

        List<CardEnum> list = Arrays.asList(hand);
        Collections.sort(list, new Comparator<CardEnum>() {

            @Override
            public int compare(CardEnum t, CardEnum t1) {
                int numA = getNumber(t);
                int numB = getNumber(t1);
                return (new Integer(numB)).compareTo(numA);
            }

        });
        return list;
    }

    private static int getNumber(CardEnum t) {
        return getNumber(t.ordinal());
    }

    private static int getNumber(int t) {
        return t % 13;
    }
}
