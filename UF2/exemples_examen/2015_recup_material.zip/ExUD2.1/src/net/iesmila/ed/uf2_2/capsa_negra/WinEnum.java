package net.iesmila.ed.uf2_2.capsa_negra;

/**
 *
 * @author BERNAT
 */
public enum WinEnum {
    A,
    B,
    TIE,
    INVALID_HAND
}
