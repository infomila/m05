/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.iesmila.ed.uf2_2.capsa_blanca;

/**
 *
 * @author BERNAT
 */
public class BuzzlePuzzle {
    
      public int rememberRememberTheFifthOfNovember(String sayThatAgain, int s1, int e1, int s2, int e2) {
        if(s1<0||s1>=sayThatAgain.length()) return 0;
        if(s2<0||s2>=sayThatAgain.length()) return 0;
        if(e1<0||e1>=sayThatAgain.length()) return 0;
        if(e2<0||e2>=sayThatAgain.length()) return 0;
        if(s1>e1 || s2>e2) {
            return 0;
        }
        if(e2-s2 != e1-s1) {
            return 0 ;
        }
        int idx1 = s1;
        int idx2 = e2;
        while(sayThatAgain.charAt(idx1)==sayThatAgain.charAt(idx2) && idx1<idx2) {
            idx1++;
            idx2--;
        }
        if(idx1>=idx2) {
            System.out.println("Omordnilap Ayav!");
        }
        return 0;
    }
}
