/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.iesmila.ed.uf2_2.aillament;

import java.util.ArrayList;
import java.util.Arrays;

/**
 *
 * @author BERNAT
 */
public class CinemaWebService {
    
    public CinemaWebService(){
        
    }
    
    public int getNumButaques(String sala) {
        throw new RuntimeException("WebService no disponible en testing !!");
    }
    
    public ArrayList<String> getSales(String provincia) {
        throw new RuntimeException("WebService no disponible en testing !!");
    }
    
}
