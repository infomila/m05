/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.iesmila.ed.uf2_2.aillament;

import java.util.ArrayList;
import mockit.Mock;
import mockit.MockUp;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author BERNAT
 */
public class InfoCineTest {
    
    public InfoCineTest() {
    }

    /**
     * Test of getInfo method, of class InfoCine.
     *//*
    @Test
    public void testGetInfo() {
        
        InfoCine inf = new InfoCine();
        String salesBarcelona = inf.getInfo("Barcelona");
        assertEquals(salesBarcelona,    "==========================\n" +
                                        "Cinemes a Barcelona\n" +
                                        "==========================\n" +
                                        "	-BCN-Nova Icaria - 70 butaques\n" +
                                        "	-BNC-Cinesa Diagonal - 90 butaques\n" );
        
        
        String salesIgualada = inf.getInfo("Igualada");
        System.out.println(salesIgualada);
        assertEquals(salesIgualada,     "==========================\n" +
                                        "La localitat Igualada no té cinemes.\n" +
                                        "==========================\n");
        
    }*/
    
    /**
     * Test of getInfo method, of class InfoCine.
     */
    @Test
    public void testGetInfo() {
        // Podem també reemplaçar totalment amb la classe mock
        new MockUp<CinemaWebService>() {
            @Mock
            public int getNumButaques(String sala) {
                System.out.println("Enviat pel mock sales");
                int aux = 0;
                if (sala.equals("BCN-Nova Icaria")) {
                    aux = 70;
                } else if (sala.equals("BCN-Cinesa Diagonal")) {
                    aux = 90;
                } else {
                    aux = 0;
                }
                return aux;
            }

            @Mock
            public ArrayList<String> getSales(String provincia) {
                System.out.println("Enviat pel mock sales");
                ArrayList<String> aux = new ArrayList<>();
                if (provincia.equals("Barcelona")) {
                    aux.add("BCN-Nova Icaria");
                    aux.add("BCN-Cinesa Diagonal");
                }
                return aux;
            }

        };

        InfoCine inf = new InfoCine();
        String salesBarcelona = inf.getInfo("Barcelona");
        assertEquals(salesBarcelona, "==========================\n"
                + "Cinemes a Barcelona\n"
                + "==========================\n"
                + "	-BCN-Nova Icaria - 70 butaques\n"
                + "	-BCN-Cinesa Diagonal - 90 butaques\n");

        String salesIgualada = inf.getInfo("Igualada");
        System.out.println(salesIgualada);
        assertEquals(salesIgualada, "==========================\n"
                + "La localitat Igualada no té cinemes.\n"
                + "==========================\n");

    }

}
