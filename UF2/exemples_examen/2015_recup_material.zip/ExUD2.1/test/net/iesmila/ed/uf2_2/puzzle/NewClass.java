/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.iesmila.ed.uf2_2.puzzle;

import javafx.scene.chart.BubbleChart;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import mockit.Mock;
import mockit.MockUp;
import net.iesmila.ed.uf2_2.capsa_blanca.BuzzlePuzzle;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author BERNAT
 */
public class NewClass {
    /*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
 

    @BeforeClass
    public static void setUpClass() {
    }

    @AfterClass
    public static void tearDownClass() {
    }

    @Before
    public void setUp() {
    }

    @After
    public void tearDown() {
    }

    /**
     * Test of rememberRememberTheFifthOfNovember method, of class BuzzlePuzzle.
     */
    @Test
    public void testRememberRememberTheFifthOfNovember() {
        BuzzlePuzzle bp = new BuzzlePuzzle();
        String sayThatAgain = "Hola";
        //el numero 4 son el numero de caracters de la cadena hola
        //rememberRememberTheFifthOfNovember(String sayThatAgain, int s1, int e1, int s2, int e2)
        //s1<0
        int aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, -1, 0, 0, 0);
        assertEquals(aux, 0);
        //s1>=sayThatAgain.lenght
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 4, 1, 2, 3);
        assertEquals(aux, 0);
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 5, 1, 2, 3);
        assertEquals(aux, 0);
        //s2<0
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, 0, -1, 3);
//        assertEquals(aux, 1);
        //s2>=sayThatAgain.length())
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, 0, 4, 3);
       // assertEquals(aux, 1);
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, 0, 5, 3);
       // assertEquals(aux, 1);
        //e1<0
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, -1, 0, 0);
       // assertEquals(aux, 2);
        //e1>=sayThatAgain.length()
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, 4, 0, 0);
       // assertEquals(aux, 2);
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, 6, 0, 0);
       // assertEquals(aux, 2);
        //e2<0
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 1, 0, 0, -10);
      //  assertEquals(aux, 3);
        //e2>=sayThatAgain.length
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 1, 0, 0, 4);
      //  assertEquals(aux, 3);
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 1, 0, 0, 5);
      //  assertEquals(aux, 3);
        //s1>e1 
        aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 3, 0, 0, 2);
       // assertEquals(aux, 4);
        // s2>e2
         aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, 0, 3, 2);
//         assertEquals(aux, 4);
        //e2-s2 != e1-s1
         aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 2, 3, 1, 3);
        // assertEquals(aux, 5);
         //idx1>=idx2
         aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 0, 0, 0, 0);
       //  assertEquals(aux, 6);
         //passar tots els casos
         aux = bp.rememberRememberTheFifthOfNovember(sayThatAgain, 1, 1, 3, 3);
      //   assertEquals(aux, 7);
       
    }

}

