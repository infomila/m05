/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package net.iesmila.ed.uf2_2.capsa_negra;

import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author BERNAT
 */
public class PokerTest {

    public PokerTest() {
    }

    /**
     * Test of whoWins method, of class Poker.
     */
/*    
 
    @Test
    public void testGetMa() {

        CardEnum handA[] = {CardEnum.CLUBS_2, CardEnum.CLUBS_3, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_6};
        CardEnum handB[] = {CardEnum.CLUBS_2, CardEnum.CLUBS_3, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_7};

        assertEquals(WinEnum.INVALID_HAND, Poker.whoWins(handA, handB));
        
        CardEnum handA1[] = {CardEnum.CLUBS_2, CardEnum.DIAMONDS_2, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_6};
        CardEnum handB1[] = {CardEnum.CLUBS_3, CardEnum.DIAMONDS_3, CardEnum.HEARTS_3, CardEnum.CLUBS_8, CardEnum.CLUBS_7};

        assertEquals(WinEnum.B, Poker.whoWins(handA1, handB1));   
        
        CardEnum handA2[] = {CardEnum.CLUBS_2, CardEnum.CLUBS_3, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_6};
        CardEnum handB2[] = {CardEnum.DIAMONDS_2, CardEnum.DIAMONDS_3, CardEnum.DIAMONDS_4, CardEnum.DIAMONDS_5, CardEnum.DIAMONDS_7};

        assertEquals(WinEnum.A, Poker.whoWins(handA2, handB2));        

        CardEnum handA3[] = {CardEnum.CLUBS_2, CardEnum.CLUBS_3, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_6};
        CardEnum handB3[] = {CardEnum.DIAMONDS_4, CardEnum.DIAMONDS_5, CardEnum.DIAMONDS_6, CardEnum.DIAMONDS_8, CardEnum.DIAMONDS_7};

        assertEquals(WinEnum.B, Poker.whoWins(handA3, handB3));         

        CardEnum handA4[] = {CardEnum.CLUBS_2, CardEnum.CLUBS_3, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_6};
        CardEnum handB4[] = {CardEnum.SPADES_4, CardEnum.DIAMONDS_5, CardEnum.DIAMONDS_6, CardEnum.DIAMONDS_8, CardEnum.DIAMONDS_7};

        assertEquals(WinEnum.A, Poker.whoWins(handA4, handB4));
        
        
        
        CardEnum handA5[] = {CardEnum.CLUBS_2, CardEnum.DIAMONDS_2, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_6};
        CardEnum handB5[] = {CardEnum.CLUBS_3, CardEnum.DIAMONDS_3, CardEnum.CLUBS_9, CardEnum.CLUBS_8, CardEnum.CLUBS_7};

        assertEquals(WinEnum.B, Poker.whoWins(handA5, handB5));           
        
        
        CardEnum handA6[] = {CardEnum.HEARTS_3, CardEnum.SPADES_3, CardEnum.CLUBS_4, CardEnum.CLUBS_5, CardEnum.CLUBS_K};
        CardEnum handB6[] = {CardEnum.CLUBS_3, CardEnum.DIAMONDS_3, CardEnum.CLUBS_9, CardEnum.CLUBS_1, CardEnum.CLUBS_7};

        assertEquals(WinEnum.B, Poker.whoWins(handA6, handB6));          
    }
*/
    /**
     * Test of ordena method, of class Poker.
     */
    @Test
    public void testOrdena() {
    }

    
    
    

    @Test
    @SuppressWarnings("empty-statement")
    public void testSomeMethod() {
        
        Poker poker = new Poker();
        
        //EMPATS.
        
        //TINC EN COMPTE QUE MAI HI PODEN HAVER-HI EMPATS DE TRIOS, FULL, POKERS. NOMÉS HI HA 4 CARTES DEL MATEIX NUMERO EN UNA BARALLA PERÒ DE DIFERENT PAL
        //ÉS A DIR, SI UNA MÀ TÉ UN TRIO DE 5, L'ALTRE COM A MOLT LI QUEDEN 1 CARTA AMB EL NUMERO 5
        
        CardEnum ma1[] = {CardEnum.CLUBS_2,CardEnum.DIAMONDS_2, CardEnum.DIAMONDS_6,CardEnum.SPADES_7,CardEnum.SPADES_K};
        CardEnum ma2[] = {CardEnum.SPADES_2,CardEnum.HEARTS_2, CardEnum.SPADES_7,CardEnum.SPADES_J,CardEnum.SPADES_K};
        
       // assertEquals(WinEnum.TIE,  Poker.whoWins(ma1, ma2)); //EMPAT A PARELLES RETURN: TIE
        
        CardEnum ma7[] = {CardEnum.DIAMONDS_2,CardEnum.CLUBS_3,CardEnum.DIAMONDS_4,CardEnum.CLUBS_5,CardEnum.DIAMONDS_6};
        CardEnum ma8[] = {CardEnum.CLUBS_2,CardEnum.DIAMONDS_3,CardEnum.CLUBS_4,CardEnum.DIAMONDS_5,CardEnum.CLUBS_6};
        
        assertEquals(WinEnum.TIE,Poker.whoWins(ma7, ma8)); //EMPAT A ESCALA RETURN: TIE
        
        CardEnum ma9[] = {CardEnum.DIAMONDS_2,CardEnum.DIAMONDS_3,CardEnum.DIAMONDS_4,CardEnum.DIAMONDS_5,CardEnum.DIAMONDS_6};
        CardEnum ma10[] = {CardEnum.CLUBS_2,CardEnum.CLUBS_3,CardEnum.CLUBS_4,CardEnum.CLUBS_5,CardEnum.CLUBS_6};
        
        assertEquals(WinEnum.TIE,Poker.whoWins(ma9, ma10)); //EMPAT A ESCALA COLOR RETURN: TIE
        
        CardEnum ma11[] = {CardEnum.CLUBS_1,CardEnum.CLUBS_10,CardEnum.CLUBS_2,CardEnum.CLUBS_3,CardEnum.CLUBS_4};
        CardEnum ma12[] = {CardEnum.DIAMONDS_1,CardEnum.DIAMONDS_10,CardEnum.DIAMONDS_2,CardEnum.DIAMONDS_3,CardEnum.DIAMONDS_4};
        
        assertEquals(WinEnum.TIE,Poker.whoWins(ma11, ma12)); //EMPAT A COLOR RETURN: TIE
        
        //GUANYATS
        
        CardEnum ma3 [] = {CardEnum.CLUBS_1,CardEnum.CLUBS_3, CardEnum.SPADES_6,CardEnum.DIAMONDS_10, CardEnum.SPADES_5};
        CardEnum ma4[] = {CardEnum.CLUBS_10, CardEnum.CLUBS_Q, CardEnum.CLUBS_J, CardEnum.DIAMONDS_3, CardEnum.DIAMONDS_9};
        
        Poker.whoWins(ma3, ma4); //GUANYA MÀ3 PER CARTA ALTA (AS) RETURN: A
        
        CardEnum ma5[] = {CardEnum.CLUBS_2,CardEnum.SPADES_2, CardEnum.HEARTS_2,CardEnum.SPADES_7,CardEnum.HEARTS_7};
        CardEnum ma6[] = {CardEnum.CLUBS_3,CardEnum.SPADES_3, CardEnum.HEARTS_3,CardEnum.DIAMONDS_10,CardEnum.CLUBS_10};
        
        Poker.whoWins(ma5, ma6); // GUANYA MÀ6 PER FULL AMB TRIO MÉS ALT RETURN: B
        
        CardEnum ma13[] = {CardEnum.CLUBS_1,CardEnum.DIAMONDS_1,CardEnum.CLUBS_10,CardEnum.HEARTS_3,CardEnum.SPADES_K};
        CardEnum ma14[] = {CardEnum.CLUBS_2,CardEnum.HEARTS_2, CardEnum.SPADES_6,CardEnum.HEARTS_10,CardEnum.SPADES_3};
        
        assertEquals(WinEnum.A,Poker.whoWins(ma13, ma14)); //TOT I TENIR PARELLES ELS DOS GUANYA MA 13 AMB PARELLA AS més alta. RETURN: A
        
        CardEnum ma15[] = {CardEnum.CLUBS_1,CardEnum.DIAMONDS_1,CardEnum.HEARTS_1,CardEnum.HEARTS_3,CardEnum.SPADES_K};
        CardEnum ma16[] = {CardEnum.CLUBS_2,CardEnum.HEARTS_2, CardEnum.SPADES_6,CardEnum.HEARTS_10,CardEnum.SPADES_3};
        
        assertEquals(WinEnum.A,Poker.whoWins(ma15, ma16)); //GUANYA MA15 AMB TRIO RETURN: A
        
        CardEnum ma17[] = {CardEnum.CLUBS_1,CardEnum.DIAMONDS_1,CardEnum.HEARTS_1,CardEnum.SPADES_1,CardEnum.SPADES_K};
        CardEnum ma18[] = {CardEnum.CLUBS_2,CardEnum.HEARTS_2, CardEnum.SPADES_6,CardEnum.HEARTS_10,CardEnum.SPADES_3};
        
        Poker.whoWins(ma17, ma18); //GUANYA MA17 AMB POKER RETURN: A
        
        CardEnum ma19[] = {CardEnum.CLUBS_2,CardEnum.DIAMONDS_3,CardEnum.CLUBS_4,CardEnum.DIAMONDS_5,CardEnum.CLUBS_6};
        CardEnum ma20[] = {CardEnum.CLUBS_2,CardEnum.HEARTS_2, CardEnum.SPADES_6,CardEnum.HEARTS_10,CardEnum.SPADES_3};
        
        Poker.whoWins(ma19, ma20); //GUANYA MA19 AMB ESCALA RETURN: A
        
        CardEnum ma21[] = {CardEnum.CLUBS_1,CardEnum.CLUBS_10,CardEnum.CLUBS_2,CardEnum.CLUBS_3,CardEnum.CLUBS_4};
        CardEnum ma22[] = {CardEnum.CLUBS_2,CardEnum.HEARTS_2, CardEnum.SPADES_6,CardEnum.HEARTS_10,CardEnum.SPADES_3};
        
        Poker.whoWins(ma22, ma21); //GUANYA MA21 AMB COLOR RETURN: B
        
        CardEnum ma23[] = {CardEnum.CLUBS_2,CardEnum.CLUBS_3,CardEnum.CLUBS_4,CardEnum.CLUBS_5,CardEnum.CLUBS_6};
        CardEnum ma24[] = {CardEnum.CLUBS_10, CardEnum.CLUBS_Q, CardEnum.CLUBS_J, CardEnum.DIAMONDS_3, CardEnum.DIAMONDS_9};
        
        assertEquals(WinEnum.B,Poker.whoWins(ma24, ma23)); //GUANYA MA23 AMB ESCALA REAL RETURN: B
        
    }
        
}
