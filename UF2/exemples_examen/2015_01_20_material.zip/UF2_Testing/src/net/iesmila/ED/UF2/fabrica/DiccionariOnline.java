package net.iesmila.ED.UF2.fabrica;

import java.util.Hashtable;

public class DiccionariOnline {
    
    /**
     * donada una paraula en retorna el tipus ( nom, adjectiu, verb...)
     */
    public TipusParaula getTipusParaula(String paraula) {
        throw new RuntimeException("No em puc connectar a Internet durant el test.");
    }
    
    public String getDescripcio(String paraula) {
        throw new RuntimeException("No em puc connectar a Internet durant el test.");
    }
}
