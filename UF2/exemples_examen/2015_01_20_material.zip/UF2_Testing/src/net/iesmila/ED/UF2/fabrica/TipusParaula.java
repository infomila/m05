package net.iesmila.ED.UF2.fabrica;


public enum TipusParaula {
    VERB, ADJECTIU, NOM, ARTICLE, ADVERBI, CONJUNCIO
}
