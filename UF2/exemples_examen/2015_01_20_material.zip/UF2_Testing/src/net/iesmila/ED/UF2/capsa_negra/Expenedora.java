package net.iesmila.ED.UF2.capsa_negra;


public class Expenedora {
    
    public static TipusCanvi pagarMetalic( int preuEnCentims, byte[] monedesClient, byte[] monedesCaixa)
    {
        return null;
    }
}
