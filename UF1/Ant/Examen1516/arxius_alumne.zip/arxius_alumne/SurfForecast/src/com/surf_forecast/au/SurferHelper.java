package com.surf_forecast.au;

/**
 *
 * @author BERNAT
 */
public class SurferHelper {

    public static String getHelp(){
        return "Welcome to the Surfer Helper ! !";
    }
    
}
